﻿using PayTr.Payment.Abstractions.Enums;

namespace PayTr.Payment.Abstractions.Models;

public sealed class PayTrOrderModel
{
    public Guid CorrelationId { get; set; }

    public string Email { get; set; } = default!;

    /// <summary>
    /// Kuruş cinsinden.
    /// Örn: 199.90 TL => 19990
    /// </summary>
    public int PaymentAmount { get; set; }

    public List<PayTrBasketItem> BasketItems { get; set; } = new();

    public string CustomerFullName { get; set; } = default!;
    public string CustomerAddress { get; set; } = default!;
    public string CustomerPhone { get; set; } = default!;

    public PaymentType PaymentType { get; set; }

    /// <summary>
    /// PAYTR merchant_oid alphanumeric sevdiği için guid '-' karakterleri 'x' ile replace ediliyor.
    /// </summary>
    public string CorreleationAsAlphaNumeric => CorrelationId.ToString().Replace("-", "x");
}
