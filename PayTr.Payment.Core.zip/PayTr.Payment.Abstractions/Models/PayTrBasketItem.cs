﻿namespace PayTr.Payment.Abstractions.Models;

public sealed record PayTrBasketItem(string Name, double UnitPrice, int Amount);