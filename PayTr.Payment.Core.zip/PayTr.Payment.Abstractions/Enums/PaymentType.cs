﻿namespace PayTr.Payment.Abstractions.Enums;

public enum PaymentType
{
    OnlineCard = 1,
    Cash = 2,
    Eft = 3,
    CardOnDelivery = 4
}
