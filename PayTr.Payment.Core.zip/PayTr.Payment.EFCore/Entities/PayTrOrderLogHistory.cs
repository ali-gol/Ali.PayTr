﻿using PayTr.Payment.Abstractions.Enums;

namespace PayTr.Payment.EFCore.Entities;

public class PayTrOrderLogHistory
{
    public int Id { get; set; }
    public PayTrOrder PayTrOrder { get; set; }
    public Guid PayTrOrderId { get; set; }
    public Guid CorrelationId { get; set; }

    public DateTimeOffset CreatedDate { get; set; }

    public OrderStatus OrderStatus { get; set; }
    public PaymentStatus PaymentStatus { get; set; }

    public string SystemNote { get; set; } = default!;
}
