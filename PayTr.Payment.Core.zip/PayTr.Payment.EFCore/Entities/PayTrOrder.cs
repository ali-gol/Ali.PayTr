﻿using PayTr.Payment.Abstractions.Enums;

namespace PayTr.Payment.EFCore.Entities;

public class PayTrOrder
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public Guid CorrelationId { get; set; }
    public PaymentType PaymentType { get; set; }
    public OrderStatus OrderStatus { get; set; }
    public PaymentStatus PaymentStatus { get; set; }

    public string BuyingItemSnapShot { get; set; } = default!;

    public string Email { get; set; } = default!;
    public string CustomerFullName { get; set; } = default!;
    public string CustomerAddress { get; set; } = default!;
    public string CustomerPhone { get; set; } = default!;

    public string PayTrHash { get; set; } = default!;
    public string PayTrToken { get; set; } = default!;

    public decimal TotalPrice { get; set; }

    public ICollection<PayTrOrderLogHistory> OrderLogHistories { get; set; } = new List<PayTrOrderLogHistory>();
    public ICollection<PayTrNotificationHistory> PayTrNotificationHistories { get; set; } = new List<PayTrNotificationHistory>();
}
