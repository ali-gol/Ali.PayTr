﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayTr.Payment.EFCore.DependencyInjection
{
    internal class ServiceCollectionExtensions
    {
    }
}
