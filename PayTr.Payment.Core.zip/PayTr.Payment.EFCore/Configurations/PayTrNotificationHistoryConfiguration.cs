﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayTr.Payment.EFCore.Configurations
{
    internal class PayTrNotificationHistoryConfiguration
    {
    }
}
