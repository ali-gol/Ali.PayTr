﻿namespace PayTr.Payment.Core.Services;

public interface IPayTrHashService
{
    string CreateTokenHash(string hashStr, string merchantKey, string merchantSalt);
}