﻿using System.Text;
using System.Text.Json;
using PayTr.Payment.Abstractions.Models;

namespace PayTr.Payment.Core.Services;

public sealed class PayTrBasketEncoder : IPayTrBasketEncoder
{
    public string EncodeToBase64(List<PayTrBasketItem> items)
    {
        var basketJson = JsonSerializer.Serialize(items.Select(x => new object[] { x.Name, x.UnitPrice, x.Amount }));

        return Convert.ToBase64String(Encoding.UTF8.GetBytes(basketJson));
    }
}
