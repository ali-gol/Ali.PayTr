﻿using System.Security.Cryptography;
using System.Text;

namespace PayTr.Payment.Core.Services;

public sealed class PayTrHashService : IPayTrHashService
{
    public string CreateTokenHash(string hashStr, string merchantKey, string merchantSalt)
    {
        var key = Encoding.UTF8.GetBytes(merchantKey);
        var data = Encoding.UTF8.GetBytes(hashStr + merchantSalt);

        using var hmac = new HMACSHA256(key);
        var hash = hmac.ComputeHash(data);

        return Convert.ToBase64String(hash);
    }
}