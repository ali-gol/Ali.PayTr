﻿using PayTr.Payment.Abstractions.Models;
using PayTr.Payment.Core.Results;

namespace PayTr.Payment.Core.Services;

public interface IPayTrService
{
    Task<PayTrTokenResult> GetTokenAsync(PayTrOrderModel model, CancellationToken cancellationToken = default);

    /// <summary>
    /// Notification hash verify (PAYTR docs).
    /// </summary>
    bool VerifyNotificationHash(OrderPayTrNotificationDto notification);
}