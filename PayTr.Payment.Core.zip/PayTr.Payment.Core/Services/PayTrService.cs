﻿using Microsoft.Extensions.Options;
using PayTr.Payment.Abstractions.Models;
using PayTr.Payment.Abstractions.Options;
using PayTr.Payment.Core.Results;
using System.Text.Json;

namespace PayTr.Payment.Core.Services;

public sealed class PayTrService : IPayTrService
{
    private readonly HttpClient _httpClient;
    private readonly PayTrOptions _options;
    private readonly IPayTrBasketEncoder _basketEncoder;
    private readonly IPayTrHashService _hashService;

    public PayTrService(
        HttpClient httpClient,
        IOptions<PayTrOptions> options,
        IPayTrBasketEncoder basketEncoder,
        IPayTrHashService hashService)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _basketEncoder = basketEncoder;
        _hashService = hashService;
    }

    public async Task<PayTrTokenResult> GetTokenAsync(PayTrOrderModel model, CancellationToken cancellationToken = default)
    {
        var basketBase64 = _basketEncoder.EncodeToBase64(model.BasketItems);
        var merchantOid = model.CorreleationAsAlphaNumeric;

        var hashStr =
            _options.MerchantId +
            merchantOid +
            model.Email +
            model.PaymentAmount.ToString() +
            basketBase64 +
            "0" + // no_installment
            "0" + // max_installment
            _options.Currency +
            (_options.TestMode ? "1" : "0");

        var paytrToken = _hashService.CreateTokenHash(hashStr, _options.MerchantKey, _options.MerchantSalt);

        var postData = new Dictionary<string, string>
        {
            ["merchant_id"] = _options.MerchantId,
            ["user_ip"] = _options.ServerIp,
            ["merchant_oid"] = merchantOid,
            ["email"] = model.Email,
            ["payment_amount"] = model.PaymentAmount.ToString(),
            ["paytr_token"] = paytrToken,
            ["user_basket"] = basketBase64,
            ["debug_on"] = "1",
            ["no_installment"] = "0",
            ["max_installment"] = "0",
            ["user_name"] = model.CustomerFullName,
            ["user_address"] = model.CustomerAddress,
            ["user_phone"] = model.CustomerPhone,
            ["merchant_ok_url"] = _options.OkUrl,
            ["merchant_fail_url"] = _options.FailUrl,
            ["timeout_limit"] = "30",
            ["currency"] = _options.Currency,
            ["test_mode"] = _options.TestMode ? "1" : "0",
            ["lang"] = _options.Language
        };

        var response = await _httpClient.PostAsync(
            "odeme/api/get-token",
            new FormUrlEncodedContent(postData),
            cancellationToken
        );

        var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);

        // PAYTR response örnek:
        // { "status":"success","token":"xxx" }
        // { "status":"failed","reason":"xxx" }

        try
        {
            using var doc = JsonDocument.Parse(responseBody);

            var status = doc.RootElement.GetProperty("status").GetString();

            if (string.Equals(status, "success", StringComparison.OrdinalIgnoreCase))
            {
                var token = doc.RootElement.GetProperty("token").GetString();

                return new PayTrTokenResult
                {
                    IsSuccess = true,
                    Token = token,
                    RawResponse = responseBody
                };
            }

            var reason = doc.RootElement.TryGetProperty("reason", out var reasonProp)
                ? reasonProp.GetString()
                : "Unknown";

            return new PayTrTokenResult
            {
                IsSuccess = false,
                Reason = reason,
                RawResponse = responseBody
            };
        }
        catch
        {
            return new PayTrTokenResult
            {
                IsSuccess = false,
                Reason = "Invalid PAYTR response",
                RawResponse = responseBody
            };
        }
    }


    public bool VerifyNotificationHash(OrderPayTrNotificationDto notification)
    {
        // PAYTR docs:
        // hash = base64(hmac_sha256(merchant_oid + merchant_salt + status + total_amount, merchant_key))

        var hashStr = notification.merchant_oid + _options.MerchantSalt + notification.status + notification.total_amount;

        var calculated = _hashService.CreateTokenHash(hashStr, _options.MerchantKey, "");
        // burada merchantSalt zaten hashStr içinde kullanıldı.
        // CreateTokenHash metodu "hashStr + merchantSalt" yaptığı için bu yöntemde salt parametresini boş geçiyoruz.

        // Alternatif: ayrı method yazıp daha temiz yapabilirsin.

        return calculated == notification.hash;
    }

}
