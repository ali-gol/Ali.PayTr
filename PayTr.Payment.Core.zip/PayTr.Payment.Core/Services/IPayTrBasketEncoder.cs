﻿using PayTr.Payment.Abstractions.Models;

namespace PayTr.Payment.Core.Services;

public interface IPayTrBasketEncoder
{
    string EncodeToBase64(List<PayTrBasketItem> items);
}
