﻿using Microsoft.Extensions.DependencyInjection;
using PayTr.Payment.Abstractions.Events;
using PayTr.Payment.Abstractions.Options;
using PayTr.Payment.Core.Services;

namespace PayTr.Payment.Core.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddPayTrPaymentsCore(
        this IServiceCollection services,
        Action<PayTrOptions> configureOptions)
    {
        services.Configure(configureOptions);

        services.AddSingleton<IPayTrBasketEncoder, PayTrBasketEncoder>();
        services.AddSingleton<IPayTrHashService, PayTrHashService>();

        services.AddScoped<IPayTrOrderEventHandler, NullPayTrOrderEventHandler>();

        services.AddHttpClient<IPayTrService, PayTrService>((sp, client) =>
        {
            var options = sp.GetRequiredService<Microsoft.Extensions.Options.IOptions<PayTrOptions>>().Value;
            client.BaseAddress = new Uri(options.BaseUrl);
            client.Timeout = TimeSpan.FromSeconds(30);
        });

        return services;
    }
}
