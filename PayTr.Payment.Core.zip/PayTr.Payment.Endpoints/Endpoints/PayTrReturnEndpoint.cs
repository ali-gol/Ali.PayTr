﻿using Microsoft.AspNetCore.Http;

namespace PayTr.Payment.Endpoints.Endpoints;

public static class PayTrReturnEndpoint
{
    public static async Task<IResult> HandleAsync(Guid correlationId)
    {
        // Bu endpoint consumer tarafında UI'ya redirect için kullanılır.
        // İstersen bunu options'a bağlı hale getirebilirsin.

        return Results.Ok(new
        {
            Message = "Payment result will be processed by PAYTR notification.",
            CorrelationId = correlationId
        });
    }
}
