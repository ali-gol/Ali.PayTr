﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using PayTr.Payment.Abstractions.Enums;
using PayTr.Payment.Abstractions.Events;
using PayTr.Payment.Abstractions.Models;
using PayTr.Payment.Core.Services;
using PayTr.Payment.Core.Utilities;
using PayTr.Payment.EFCore.Entities;
using System.Net.Http;

namespace PayTr.Payment.Endpoints.Endpoints;

internal static class PayTrNotificationEndpoint
{
    internal static async Task<IResult> HandleAsync(
        IHttpContextAccessor httpContextAccessor,
        IPayTrService payTrService,
        IPayTrOrderEventHandler eventHandler,
        IDbContext dbContext,
        CancellationToken cancellationToken)
    {
        var form = await httpContextAccessor.HttpContext.Request.ReadFormAsync(cancellationToken);
        if(form is null)
        {
            throw new Exception("PayTR Notifion received, but FormBody received null");
        }
        var notification = new OrderPayTrNotificationDto
        {
            merchant_id = form["merchant_id"]!,
            merchant_oid = form["merchant_oid"]!,
            status = form["status"]!,
            total_amount = form["total_amount"]!,
            hash = form["hash"]!,
            failed_reason_code = form["failed_reason_code"]!,
            failed_reason_msg = form["failed_reason_msg"]!,
            payment_type = form["payment_type"]!,
            currency = form["currency"]!,
            test_mode = form["test_mode"]!
        };

        var correlationId = MerchantOidConverter.ToGuid(notification.merchant_oid);

        // Hash verify
        var isVerified = payTrService.VerifyNotificationHash(notification);

        // Order + histories için set
        var orders = dbContext.Set<PayTrOrder>();
        var orderLogs = dbContext.Set<PayTrOrderLogHistory>();
        var notificationLogs = dbContext.Set<PayTrNotificationHistory>();

        var order = await orders
            .FirstOrDefaultAsync(x => x.CorrelationId == correlationId, cancellationToken);

        if (order is null)
        {
            // PAYTR "OK" bekliyor.
            // Order yoksa bile OK dönmek gerekir (PAYTR tekrar tekrar vurmasın diye).
            return Results.Text("OK");
        }

        // Notification history log
        var notificationHistory = new PayTrNotificationHistory
        {
            merchant_oid = notification.merchant_oid,
            status = notification.status,
            hash = notification.hash,
            total_amount = notification.total_amount,
            failed_reason_code = notification.failed_reason_code,
            failed_reason_msg = notification.failed_reason_msg,
            payment_type = notification.payment_type,
            currency = notification.currency,
            test_mode = notification.test_mode,
            IsHashVerified = isVerified
        };

        notificationLogs.Add(notificationHistory);

        // Hash doğrulanmadıysa ödeme kabul etmiyoruz ama logluyoruz
        if (!isVerified)
        {
            order.OrderStatus = OrderStatus.CompletedWithFail;
            order.PaymentStatus = PaymentStatus.Failed;

            orderLogs.Add(new PayTrOrderLogHistory
            {
                CorrelationId = correlationId,
                CreatedDate = DateTimeOffset.UtcNow,
                OrderStatus = order.OrderStatus,
                PaymentStatus = order.PaymentStatus,
                SystemNote = "PAYTR notification hash verification failed."
            });

            await dbContext.SaveChangesAsync(cancellationToken);
            return Results.Text("OK");
        }

        // PAYTR status
        if (string.Equals(notification.status, "success", StringComparison.OrdinalIgnoreCase))
        {
            order.OrderStatus = OrderStatus.CompletedWithSuccess;
            order.PaymentStatus = PaymentStatus.Paid;

            orderLogs.Add(new PayTrOrderLogHistory
            {
                CorrelationId = correlationId,
                CreatedDate = DateTimeOffset.UtcNow,
                OrderStatus = order.OrderStatus,
                PaymentStatus = order.PaymentStatus,
                SystemNote = "Payment succeeded via PAYTR notification."
            });

            await dbContext.SaveChangesAsync(cancellationToken);

            await eventHandler.OnPaymentSucceededAsync(correlationId, notification);

            return Results.Text("OK");
        }

        // failed
        order.OrderStatus = OrderStatus.CompletedWithFail;
        order.PaymentStatus = PaymentStatus.Failed;

        orderLogs.Add(new PayTrOrderLogHistory
        {
            CorrelationId = correlationId,
            CreatedDate = DateTimeOffset.UtcNow,
            OrderStatus = order.OrderStatus,
            PaymentStatus = order.PaymentStatus,
            SystemNote = $"Payment failed via PAYTR. ReasonCode={notification.failed_reason_code}, Msg={notification.failed_reason_msg}"
        });

        await dbContext.SaveChangesAsync(cancellationToken);

        await eventHandler.OnPaymentFailedAsync(correlationId, notification);

        return Results.Text("OK");
    }
}
