﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using PayTr.Payment.Endpoints.Endpoints;

namespace PayTr.Payment.Endpoints.EndpointMapping;

public static class PayTrEndpointRouteBuilderExtensions
{
    public static IEndpointRouteBuilder MapPayTrPaymentEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapPost("/paytr/notification", PayTrNotificationEndpoint.HandleAsync);
        app.MapGet("/paytr/return/{correlationId:guid}", PayTrReturnEndpoint.HandleAsync);

        return app;
    }
}
