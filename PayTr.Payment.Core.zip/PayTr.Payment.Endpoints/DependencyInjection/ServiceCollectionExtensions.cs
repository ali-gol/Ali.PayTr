﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PayTr.Payment.Endpoints.DependencyInjection
{
    internal class ServiceCollectionExtensions
    {
    }
}
